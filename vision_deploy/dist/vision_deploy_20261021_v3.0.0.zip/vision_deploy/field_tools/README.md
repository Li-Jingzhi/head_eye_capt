# 交付现场工具集

`head_eye_pro/`包含本教程所需的相机启动、CSI6标定/对比、左臂拖动视觉/FK对比、左右臂示教回放源码及相机/MDH配置。它是现场运行工具子集，不含原始数据、研究拟合报告或厂商二进制。

1. 本机进入本目录的`head_eye_pro/`，依主交付说明运行原入口。
2. 若要控制机械臂，另行把SDK00040701放在本目录的`00040701/`；路径应为`field_tools/00040701/PYTHON_SDK/GentoRobot.py`。相机查看不需要SDK。
3. 工具内的`vision_deploy/stereo_robot/`是主交付目录当前v3.0.0代码及参数的精确副本，保障原入口可直接导入；打包时已核对一致。更新模型时需重新打包或同步这两份，不只替换其中一份。
4. Orin驱动、Argus/VPI/GStreamer、本机GStreamer版OpenCV、Paramiko和SDK动态库需按目标平台另行准备。普通pip OpenCV不保证支持视频接收后端。
5. 教程中的原机器项目绝对路径替换为本工具目录；当前Orin/控制器/接收IP仍为123/190/101，需按现场核对。

本目录的测试只用模拟器/合成图，不连接控制器或相机。可在`head_eye_pro/`运行：

```bash
/usr/bin/python3 -m unittest discover -s tests
```

本工具集和SDK位置不由wheel安装；使用ZIP中的目录。相机启动脚本会写入此目录的runtime/data，原始交付包中这两个目录只有空占位文件。
